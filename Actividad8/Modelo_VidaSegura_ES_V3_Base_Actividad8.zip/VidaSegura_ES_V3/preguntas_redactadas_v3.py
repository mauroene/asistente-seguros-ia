"""Preguntas sintéticas redactadas por intención. No contienen respuestas contractuales."""
# Categoría -> (familia, referencia temática, cuatro redacciones).
DESARROLLO = {
'LIFE_INSURANCE': [
('numero_poliza','BBVA_VS_009',[
'Para qué sirve el número que identifica mi póliza de vida',
'No sé qué significa el folio de mi seguro, ¿me explicas?',
'Explícame qué es el identificador de una póliza.',
'¿A qué se refiere el número de contrato del seguro de vida?']),
('prima_concepto','BBVA_VS_023',[
'¿Qué significa prima en un seguro de vida?',
'Cuando dicen prima del seguro, ¿de qué están hablando?',
'Explícame el concepto de prima, por favor.',
'¿La palabra prima qué representa dentro de una póliza?']),
('prima_no_devengada_concepto','BBVA_VS_035',[
'¿Qué quiere decir prima no devengada?',
'No entiendo el término prima devengada, ¿qué significa?',
'¿Cómo se define la parte no devengada de una prima?',
'Quiero entender la diferencia entre prima consumida y no devengada.']),
('siniestro_concepto','BBVA_VS_052',[
'Explícame qué significa la palabra siniestro.',
'¿A qué le llaman siniestro en los seguros de vida?',
'Solo quiero entender qué es un evento asegurado.',
'No conozco el concepto de siniestro, ¿me lo puedes definir?']),
('preexistencia_concepto','BBVA_VS_015',[
'¿Qué significa que una enfermedad sea preexistente?',
'¿A qué se refiere el término padecimiento preexistente?',
'Necesito una definición de preexistencia.',
'¿Cómo se entiende el concepto de enfermedad previa en el contrato?']),
('endoso_concepto','BBVA_VS_098',[
'¿Qué es un endoso del seguro de vida?',
'Explícame el término endoso, no sé qué documento es.',
'¿Qué significa la palabra endoso en una póliza?',
'¿Para qué sirve en general un endoso de seguro?']),
('espera_concepto','BBVA_VS_055',[
'¿Qué significa periodo de espera en los seguros?',
'¿A qué le llaman plazo de espera?',
'Explícame el concepto de periodo de espera, sin calcular fechas.',
'¿Cuál es la definición de periodo de espera de una póliza?']),
('asistencia_concepto','BBVA_VS_045',[
'¿Qué quiere decir asistencia dentro de un seguro?',
'Me puedes explicar qué se entiende por un servicio de asistencia',
'¿Qué significa que la póliza incluya asistencias?',
'Necesito una definición general de asistencia en seguros.'])],
'COVERAGE': [
('edad_admision','BBVA_VS_029',[
'¿Hasta qué edad aceptan personas para este seguro de vida?',
'¿Cuál es el rango de edades permitido para entrar al seguro?',
'¿Puedo ser aceptado si ya cumplí sesenta años?',
'Necesito conocer la edad mínima y máxima de admisión.']),
('catalogo_coberturas','BBVA_VS_011',[
'¿Qué protecciones vienen incluidas en VidaSegura?',
'Dime cuáles beneficios básicos y adicionales ofrece esta póliza.',
'¿Qué riesgos ampara mi seguro de vida de BBVA?',
'Necesito conocer la lista de coberturas del producto.']),
('catalogo_asistencias','BBVA_VS_045',[
'¿Qué servicios de asistencia contempla el seguro de vida?',
'Dime qué asistencias incluye este producto.',
'¿Cuáles ayudas de hogar, salud o vehículo forman parte de la póliza?',
'Quiero conocer los servicios adicionales de asistencia disponibles en el seguro.']),
('hogar_alcance','BBVA_VS_045',[
'¿En qué casos queda cubierta una emergencia de cerrajería?',
'¿El apoyo para mi casa incluye plomería?',
'¿Qué trabajos del hogar entran en la asistencia?',
'¿Hay un tope para las reparaciones de vivienda incluidas?']),
('vial_alcance','BBVA_VS_047',[
'¿Qué servicios contempla el auxilio para mi coche?',
'¿La asistencia vehicular incluye remolque?',
'¿Qué cubre la ayuda en carretera que viene con mi seguro de vida?',
'¿Hay un límite de distancia para el servicio de grúa?']),
('fallecimiento_exclusiones','BBVA_VS_011',[
'¿En qué circunstancias no aplica el beneficio por fallecimiento?',
'¿Cuáles son las exclusiones de la protección por muerte?',
'¿Qué situaciones dejan fuera de cobertura un fallecimiento?',
'¿El beneficio de fallecimiento tiene restricciones?']),
('dental_alcance','BBVA_VS_128',[
'¿Qué tratamientos entran en el plan dental incluido?',
'¿La limpieza dental está contemplada en la asistencia?',
'¿Hay límites de consultas para el servicio odontológico?',
'¿Qué procedimientos de dientes no incluye la asistencia?']),
('espera_cobertura','BBVA_VS_055',[
'¿Cuánto tiempo debe pasar para que aplique la cobertura de cáncer?',
'¿Desde qué momento queda cubierta una enfermedad grave?',
'¿Qué plazo de espera aplica al beneficio por cáncer?',
'¿Cuántos días debo esperar para usar esa protección?'])],
'QUOTE': [
('descuento_precio','BBVA_VS_059',[
'¿Hay alguna rebaja en el precio del seguro de vida?',
'¿Se puede obtener una prima más económica con algún descuento?',
'Quisiera saber si existe una promoción que reduzca el costo.',
'¿Ofrecen descuentos al cotizar VidaSegura?']),
('precio_salud','BBVA_VS_059',[
'¿Tener una enfermedad previa modifica el precio de mi póliza?',
'¿Mi estado de salud influye en la prima que me cotizan?',
'¿Me saldría más caro el seguro por mis antecedentes médicos?',
'¿Los padecimientos que declaro cambian el costo de contratar?']),
('precio_por_edad','BBVA_VS_059',[
'¿El seguro se encarece al cumplir años?',
'¿Mi edad determina cuánto cuesta la prima?',
'¿Por qué cambia el precio de una cotización según la edad?',
'¿Paga una prima distinta alguien de cuarenta que alguien de veinte?']),
('precio_renovacion_futura','BBVA_VS_028',[
'¿La renovación tendrá una prima más alta?',
'¿Puede subir el costo del seguro cuando renuevo?',
'¿Me cobran un precio distinto por renovar el próximo periodo?',
'¿De qué depende el precio de la siguiente anualidad?']),
('precio_asistencias','BBVA_VS_060',[
'¿Cuánto baja el costo si dejo fuera las asistencias?',
'¿Agregar un paquete de asistencia cambia la prima cotizada?',
'¿Qué diferencia de precio tiene la póliza con y sin esos servicios?',
'¿Se reduce el precio si contrato menos asistencias?']),
('precio_coberturas','BBVA_VS_060',[
'¿Qué cuesta añadir una cobertura a mi seguro?',
'¿La prima sería menor si elijo menos protecciones?',
'Quiero comparar cuánto vale el seguro con distintos beneficios.',
'¿Cómo cambia el costo si retiro un beneficio adicional?']),
('descuento_modalidad','BBVA_VS_025',[
'¿Sale más barato pagar la anualidad completa?',
'¿Obtengo descuento si elijo pagar todo el año de una vez?',
'¿Hay rebaja por elegir una modalidad de pago distinta?',
'¿Qué forma de pago tiene el precio más económico?']),
('precio_aumento_suma','BBVA_VS_139',[
'¿Sube la prima al elegir más dinero de protección?',
'¿Qué precio tendría una suma asegurada más alta?',
'¿Me sale más económico asegurar un monto menor?',
'Quisiera estimar el costo de ampliar el capital de mi seguro.'])],
'PAYMENT': [
('cobro_fin_vigencia','BBVA_VS_023',[
'¿Por qué siguen haciendo cargos si terminó la vigencia?',
'Ya venció la póliza y todavía me descuentan la prima.',
'¿El cargo a mi tarjeta continúa cuando se acaba el periodo?',
'Quiero aclarar un cobro posterior al vencimiento del seguro.']),
('devolucion_prima','BBVA_VS_035',[
'¿Me regresan parte de lo pagado si doy de baja el seguro?',
'¿Cómo recupero la prima que no se consumió después de cancelar?',
'Solicité la baja y falta el reembolso de mi prima.',
'¿En qué fecha depositan la devolución de la parte no utilizada?']),
('medios_pago','BBVA_VS_023',[
'¿Con qué medios puedo liquidar la prima?',
'¿Aceptan efectivo para pagar el seguro de vida?',
'¿Se puede abonar la prima con una tarjeta?',
'¿Puedo hacer el pago por transferencia bancaria?']),
('domiciliacion','BBVA_VS_023',[
'¿Puedo dejar autorizado el cargo de la prima?',
'¿El seguro se paga mediante descuento automático?',
'¿Cómo activo el débito mensual de mi prima?',
'¿Se puede domiciliar el pago de la póliza?']),
('factura_prima','BBVA_VS_023',[
'Necesito el comprobante fiscal del pago del seguro.',
'¿Cómo solicito una factura de la prima que pagué?',
'¿Dónde consigo el recibo de mi último pago?',
'Quiero descargar la factura correspondiente a mi seguro de vida.']),
('plazo_pago','BBVA_VS_024',[
'¿Cuál es la fecha límite para cubrir mi prima?',
'¿Hasta cuándo puedo pagar la mensualidad del seguro?',
'¿Cuántos días tengo para liquidar el recibo?',
'Se venció mi pago, ¿todavía puedo cubrirlo en el plazo de gracia?']),
('cargo_duplicado','BBVA_VS_023',[
'La prima se cobró dos veces este mes.',
'¿Cómo aclaro un descuento duplicado del seguro?',
'Veo dos cargos de la misma póliza en mi estado de cuenta.',
'Necesito revisar por qué descontaron la mensualidad por duplicado.']),
('pago_fraccionado','BBVA_VS_025',[
'¿En cuántos pagos puedo dividir la prima anual?',
'Quiero saber cómo se distribuyen las mensualidades del seguro.',
'¿Qué periodicidades de pago puedo elegir?',
'¿Puedo liquidar la prima en abonos trimestrales?'])],
'ENROLLMENT': [
('contratacion_nueva','BBVA_VS_029',[
'¿Por dónde se realiza la contratación del seguro de vida?',
'¿Qué pasos debo seguir para comprar una póliza?',
'¿Cuáles son los requisitos para darme de alta en VidaSegura?',
'¿Se puede tramitar la contratación en línea o en sucursal?']),
('rehabilitacion','BBVA_VS_036',[
'¿Qué requisitos hay para volver a activar mi seguro?',
'¿Qué documentos necesito para rehabilitar la póliza?',
'Mi seguro dejó de estar vigente, ¿puedo recuperarlo?',
'¿Cómo solicito la reactivación de una póliza que se canceló?']),
('cambio_beneficiarios','BBVA_VS_003',[
'¿Puedo poner a otra persona como beneficiaria?',
'Quiero quitar a un beneficiario y registrar a otro.',
'¿Es posible actualizar los porcentajes de mis beneficiarios?',
'¿Qué tengo que presentar para cambiar mi designación?']),
('actualizar_datos','BBVA_VS_098',[
'¿Puedo corregir mi domicilio registrado en el seguro?',
'¿Cómo actualizo mi nombre en la póliza de vida?',
'Necesito modificar los datos de mi contrato, ¿se puede?',
'¿Qué trámite hago para rectificar mi información personal?']),
('endoso_gestion','BBVA_VS_098',[
'¿Cómo se solicita un endoso de mi póliza?',
'¿Qué modificaciones puedo tramitar mediante un endoso?',
'Quiero aplicar un endoso para corregir el contrato.',
'¿Qué debo entregar para pedir una modificación por endoso?']),
('caratula_actualizada','BBVA_VS_098',[
'Ya hicieron el cambio, ¿cómo obtengo la póliza actualizada?',
'¿Cómo descargo mi carátula después de modificar los datos?',
'Necesito que me entreguen el documento con el endoso aplicado.',
'¿Cómo consigo una copia del contrato con la modificación registrada?']),
('cancelacion','BBVA_VS_033',[
'¿Qué necesito para dar por terminado mi seguro de vida?',
'¿Puedo pedir la baja de mi póliza desde la aplicación?',
'¿Por qué medio se presenta una solicitud de cancelación?',
'Ya no quiero continuar con el contrato, ¿cómo lo cancelo?']),
('renovacion_ciclo','BBVA_VS_028',[
'¿La póliza de vida se renueva automáticamente?',
'¿Qué debo hacer para renovar mi contrato?',
'¿Tengo que solicitar la renovación cada año?',
'¿Cómo confirmo que se realizó la renovación de mi seguro?'])],
'CONTACT': [
('contacto_duda','BBVA_VS_058',[
'Tengo una duda del seguro, ¿a qué número llamo?',
'¿Dónde me atiende una persona para aclarar mi póliza?',
'¿Me facilitas el contacto de atención de seguros de vida?',
'Necesito que alguien me asesore sobre VidaSegura.']),
('horario_asesoria','BBVA_VS_058',[
'¿En qué horario atienden las dudas de pólizas?',
'¿Hasta qué hora puedo llamar a un asesor?',
'¿Hay atención de seguros durante el fin de semana?',
'¿Qué días puedo comunicarme con atención al cliente?']),
('contacto_cambios','BBVA_VS_058',[
'¿Con quién hablo para modificar los datos de mi póliza?',
'Necesito el teléfono para cambiar beneficiarios.',
'¿A qué área llamo para actualizar mi seguro?',
'¿Dónde puedo comunicarme con alguien que tramite un endoso?']),
('contacto_cancelacion','BBVA_VS_058',[
'¿Con quién me comunico para dar de baja el seguro?',
'¿Qué teléfono atiende solicitudes de cancelación?',
'¿Me pueden pasar con un asesor para cancelar?',
'Dame el contacto del área que atiende las bajas de pólizas.']),
('asesor_reclamaciones','BBVA_VS_058',[
'¿Cuál es el número para hablar con el área de siniestros?',
'¿En qué horario contestan llamadas sobre indemnizaciones?',
'¿Con quién me comunico para reportar la muerte del asegurado?',
'¿A qué teléfono puedo llamar por un reclamo pendiente?']),
('asesor_pagos','BBVA_VS_023',[
'¿Con quién puedo hablar para saber cuánto debo de prima?',
'¿Cuál es el teléfono para aclarar un cargo del seguro?',
'¿Me comunicas con alguien que revise mis pagos?',
'Quiero un asesor humano para ver la devolución de mi prima.']),
('coordinacion_hogar','BBVA_VS_125',[
'Se rompió una tubería, necesito que envíen la asistencia contratada.',
'¿Me ayudan a pedir al cerrajero del servicio incluido?',
'Quiero coordinar una visita de asistencia a mi casa.',
'Necesito activar la ayuda de plomería mediante el prestador.']),
('coordinacion_grua','BBVA_VS_048',[
'Estoy varado y necesito que manden la grúa de mi asistencia.',
'¿Me ayudan a solicitar el remolque incluido en la póliza?',
'Quiero contactar a la cabina para activar el auxilio del coche.',
'Necesito coordinar el traslado del vehículo con el proveedor.'])],
'CLAIMS': [
('plazo_indemnizacion','BBVA_VS_117',[
'¿En cuánto tiempo pagan un siniestro de vida?',
'¿Cuándo depositan la indemnización del fallecimiento?',
'¿Cuánto tarda en llegar el dinero del beneficio reclamado?',
'¿Qué plazo tiene la aseguradora para resolver mi reclamo?']),
('monto_indemnizacion','BBVA_VS_052',[
'¿Cómo reviso cuánto me corresponde por el siniestro?',
'El depósito de mi indemnización no coincide con lo esperado.',
'¿Dónde verifico el monto aprobado de mi reclamo?',
'Quiero aclarar la cantidad que van a pagar por fallecimiento.']),
('acreditar_beneficiario','BBVA_VS_052',[
'¿Qué documento demuestra que soy beneficiario para cobrar?',
'¿Cómo acredito mi derecho a reclamar la suma asegurada?',
'Necesito probar que me designaron para recibir la indemnización.',
'¿Qué presento para comprobar mi calidad de beneficiario del siniestro?']),
('reclamo_sin_poliza','BBVA_VS_052',[
'Perdí el contrato, ¿puedo presentar el reclamo por fallecimiento?',
'¿Puedo pedir la indemnización sin conocer el folio de la póliza?',
'¿Cómo inicio un reclamo si no encuentro el número de seguro?',
'Para cobrar el beneficio, ¿es indispensable tener la póliza física?']),
('canal_reclamo','BBVA_VS_052',[
'¿Dónde se entrega una solicitud de indemnización?',
'¿Se puede presentar el reclamo de siniestro por internet?',
'¿Por qué medios puedo entregar el expediente de fallecimiento?',
'¿Tengo que acudir a una oficina para reclamar el beneficio?']),
('seguimiento_reclamacion','BBVA_VS_113',[
'¿Dónde veo el avance de mi trámite de indemnización?',
'¿Ya revisaron los documentos de mi siniestro?',
'Necesito saber qué pasó con la solicitud de pago que entregué.',
'¿Cómo consulto si mi reclamación fue aprobada?']),
('reclamar_fallecimiento','BBVA_VS_052',[
'Falleció mi esposo asegurado, ¿qué debo presentar para cobrar?',
'¿Quién tiene derecho a reclamar el seguro después de una muerte?',
'¿Qué papeles solicitan para pagar el beneficio de fallecimiento?',
'¿Cómo tramito la entrega del capital asegurado al beneficiario?']),
('entregar_pruebas','BBVA_VS_112',[
'Faltó un documento en el reclamo, ¿cómo lo agrego?',
'¿Qué hago para completar los papeles del expediente del siniestro?',
'La aseguradora pidió más pruebas para indemnizarme, ¿cómo las entrego?',
'¿Puedo adjuntar un informe adicional a mi solicitud de indemnización?'])]
}

# Prueba nueva: familias redactadas y fijadas antes de entrenar. No se usan para selección.
# Es sintética del mismo autor, no independiente de la temática ni prueba externa.
PRUEBA = {
'LIFE_INSURANCE':[
('vigencia_concepto','BBVA_VS_028',['La expresión vigencia del contrato me confunde, ¿qué quiere decir?','¿Cómo se define la vigencia de un seguro de vida?','¿Qué diferencia hay entre fecha de emisión y vigencia?']),
('riesgo_concepto','BBVA_VS_011',['¿Qué se entiende por riesgo asegurado?','No conozco el significado de riesgo en una póliza de vida.','¿Cómo explicarías el concepto de riesgo del seguro?']),
('fallecimiento_concepto','BBVA_VS_011',['¿Qué significa fallecimiento para efectos del seguro?','Necesito entender el término fallecimiento del asegurado.','¿A qué evento se refiere la palabra fallecimiento en este contrato?'])],
'COVERAGE':[
('territorio_cobertura','BBVA_VS_047',['Si el coche se avería en otra ciudad, ¿la asistencia también lo cubre?','¿El auxilio vehicular tiene restricciones por zona geográfica?','¿Qué territorio queda amparado para el servicio vial?']),
('acompanante_cobertura','BBVA_VS_079',['¿La asistencia médica protege solo al titular o también a familiares?','¿Quiénes pueden usar la ayuda médica incluida según la póliza?','¿Hay condiciones de parentesco para las asistencias médicas?']),
('numero_eventos','BBVA_VS_045',['¿Cuántas emergencias de hogar atiende la asistencia en un año?','¿Hay una cantidad máxima de servicios de cerrajería cubiertos?','¿Existe límite de eventos para solicitar plomería amparada?'])],
'QUOTE':[
('presupuesto_limite','BBVA_VS_059',['Tengo un presupuesto mensual limitado, ¿qué cotización podrían ofrecerme?','¿Cuánta protección podría cotizar con trescientos pesos al mes?','Busco una propuesta de precio que se ajuste a mi presupuesto.']),
('comparacion_dos_personas','BBVA_VS_059',['¿Me hacen dos presupuestos, uno para mí y otro para mi pareja?','Quiero comparar el costo de asegurar por separado a dos personas.','¿Cuánto saldrían dos pólizas de vida individuales?']),
('costo_misma_proteccion','BBVA_VS_060',['¿Qué cotización tendría conservar el mismo capital el próximo año?','Quiero estimar el costo futuro sin aumentar mi protección.','¿Me presupuestan la renovación con la misma suma contratada?'])],
'PAYMENT':[
('tarjeta_vencida','BBVA_VS_023',['Venció la tarjeta donde cobran mi prima, ¿cómo actualizo el pago?','Cambié de plástico bancario y necesito que el cargo se haga al nuevo.','¿Cómo sustituyo la tarjeta para que no se interrumpa el cobro?']),
('devolucion_no_recibida','BBVA_VS_035',['Me confirmaron el reembolso de la prima pero no aparece en mi cuenta.','¿Cómo rastreo el depósito de la prima que me van a regresar?','No recibí la devolución del seguro cancelado, ¿qué reviso?']),
('comprobante_extraviado','BBVA_VS_023',['Perdí el recibo de la prima que ya cubrí, ¿puedo recuperarlo?','¿Dónde obtengo otra copia del comprobante de pago del seguro?','Necesito demostrar que liquidé la prima, pero no encuentro el recibo.'])],
'ENROLLMENT':[
('correccion_fecha_nacimiento','BBVA_VS_098',['Mi fecha de nacimiento quedó mal, ¿cómo corrijo el contrato?','¿Qué trámite actualiza el día de nacimiento en mi póliza?','Registraron incorrectamente mi nacimiento y necesito modificarlo.']),
('revocar_no_renovacion','BBVA_VS_031',['Pedí no renovar, pero cambié de opinión, ¿cómo solicito continuar?','¿Puedo retirar la solicitud de no renovación de mi póliza?','Necesito tramitar que siga vigente el seguro que había pedido no renovar.']),
('confirmar_endoso','BBVA_VS_098',['¿Cómo verifico que ya aplicaron la modificación a mi contrato?','Presenté un endoso, ¿cómo confirmo que quedó registrado?','¿Dónde reviso si ya está actualizado mi seguro después del cambio?'])],
'CONTACT':[
('contacto_por_via_alterna','BBVA_VS_058',['No logro comunicarme por teléfono, ¿hay otro canal de atención?','¿Puedo hablar con un asesor por algún medio distinto a la llamada?','Necesito una vía alternativa para contactar a una persona de seguros.']),
('coordinar_dental','BBVA_VS_128',['Necesito que me agenden la consulta dental de mi asistencia.', '¿Con qué proveedor coordino mi cita de odontología incluida?', 'Quiero activar el servicio de dentista que tengo contratado.']),
('coordinar_medico','BBVA_VS_123',['¿Me envían al médico de la asistencia a mi domicilio?','Necesito coordinar una visita del doctor mediante el servicio contratado.','¿Quién me ayuda a activar la consulta médica domiciliaria?'])],
'CLAIMS':[
('corregir_expediente','BBVA_VS_112',['Me equivoqué en los datos del reclamo, ¿cómo corrijo el expediente?','¿Puedo rectificar la información entregada para cobrar el siniestro?','Necesito corregir mi solicitud de indemnización ya presentada.']),
('rechazo_por_documentos','BBVA_VS_115',['No aceptaron mis documentos para indemnizarme, ¿cómo lo impugno?','¿Qué hago si rechazaron el reclamo por un papel que sí entregué?','Quiero inconformarme por la negativa de indemnización basada en documentación.']),
('acuse_recepcion','BBVA_VS_112',['Entregué los papeles del siniestro, ¿cómo obtengo constancia de recepción?','Necesito el acuse de la solicitud de indemnización que presenté.','¿Dónde compruebo que recibieron el expediente de mi reclamo?'])]
}
