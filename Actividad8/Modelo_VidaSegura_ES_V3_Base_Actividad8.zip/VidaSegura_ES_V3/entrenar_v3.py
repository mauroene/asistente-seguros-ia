from pathlib import Path
import argparse,json,hashlib,datetime,time,uuid,sys,subprocess,platform,shutil
import numpy as np
import pandas as pd
import scipy,sklearn,joblib
from sklearn.pipeline import Pipeline,FeatureUnion
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedGroupKFold,cross_val_score
from sklearn.metrics import accuracy_score,f1_score,classification_report,confusion_matrix

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--insumos',type=Path,required=True);ap.add_argument('--salida',type=Path,required=True);args=ap.parse_args();I=args.insumos.resolve();O=args.salida.resolve()
 if O.exists() and any(O.iterdir()):raise RuntimeError('La carpeta de salida debe estar vacía para conservar evidencias anteriores.')
 for sub in ['modelos','metricas','evidencias','configuracion','particiones']: (O/sub).mkdir(parents=True,exist_ok=True)
 events=O/'evidencias/eventos.jsonl'
 def event(name,**kw):
  rec={'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'evento':name,**kw}
  with events.open('a',encoding='utf-8') as f:f.write(json.dumps(rec,ensure_ascii=False)+'\n')
  print(json.dumps(rec,ensure_ascii=False),flush=True)
 run='es_v3_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:6]
 manifest=json.loads((I/'MANIFEST_SHA256.json').read_text())
 for name,expected in manifest.items():assert sha(I/name)==expected,name
 versions={m.__name__:m.__version__ for m in [np,pd,scipy,sklearn,joblib]};assert sklearn.__version__=='1.6.1',versions
 event('inicio',run_id=run,versiones=versions)
 protocol=json.loads((I/'protocolo_v3.json').read_text());dump(O/'configuracion/protocolo_v3.json',protocol)
 df=pd.read_csv(I/'desarrollo_v3.csv',keep_default_na=False);cats=sorted(df.categoria.unique())
 assert len(df)==448 and df.groupby('categoria').size().eq(64).all()
 folds=list(StratifiedGroupKFold(n_splits=4,shuffle=True,random_state=43).split(df.consulta_es,df.categoria,df.grupo_particion));foldrows=[]
 for n,(a,b) in enumerate(folds,1):
  assert set(df.iloc[a].grupo_particion).isdisjoint(df.iloc[b].grupo_particion)
  assert set(df.iloc[a].categoria)==set(cats)==set(df.iloc[b].categoria)
  foldrows.extend({'id':df.iloc[j].id,'grupo_particion':df.iloc[j].grupo_particion,'fold_validacion':n} for j in b)
 pd.DataFrame(foldrows).to_csv(O/'particiones/folds_cv.csv',index=False,encoding='utf-8-sig')
 shutil.copy2(I/'desarrollo_v3.csv',O/'particiones/entrenamiento.csv')
 def pipeline(clf):
  features=FeatureUnion([('palabras',TfidfVectorizer(ngram_range=(1,2),max_features=8000,sublinear_tf=True,strip_accents='unicode')),
                         ('caracteres',TfidfVectorizer(analyzer='char_wb',ngram_range=(3,5),min_df=2,max_features=15000,sublinear_tf=True))],transformer_weights={'palabras':1.0,'caracteres':0.5})
  return Pipeline([('tfidf',features),('clasificador',clf)])
 candidates={f'regresion_logistica_C{c}':pipeline(LogisticRegression(C=c,max_iter=3000,class_weight='balanced',random_state=42)) for c in [1,4,12]}
 candidates['random_forest_400']=pipeline(RandomForestClassifier(n_estimators=400,class_weight='balanced_subsample',random_state=42,n_jobs=2))
 scores=[]
 for name,model in candidates.items():
  t=time.perf_counter();v=cross_val_score(model,df.consulta_es,df.categoria,cv=folds,scoring='f1_macro',n_jobs=1,error_score='raise')
  row={'candidato':name,'f1_macro_cv_media':float(v.mean()),'f1_macro_cv_desviacion':float(v.std()),'segundos':time.perf_counter()-t,**{f'fold_{i+1}':float(x) for i,x in enumerate(v)}};scores.append(row);event('validacion_cruzada',**row)
 scores=pd.DataFrame(scores);scores.to_csv(O/'metricas/comparacion_cv.csv',index=False,encoding='utf-8-sig')
 name=scores.sort_values('f1_macro_cv_media',ascending=False,kind='stable').iloc[0].candidato
 dump(O/'configuracion/decision_previa_pruebas.json',{'seleccionado':name,'criterio':'F1 macro CV de desarrollo; decisión guardada antes de evaluar pruebas.','run_id':run})
 selected=candidates[name];selected.fit(df.consulta_es,df.categoria);modelpath=O/'modelos/modelo_seleccionado.joblib';joblib.dump(selected,modelpath,compress=3)
 # Las pruebas se leen y puntúan solo después de fijar la selección.
 baseline=joblib.load(I/'baseline_v2.joblib');summary=[]
 for label,file,textcol,catcol in [('sintetica_nueva_63','prueba_sintetica_63.csv','consulta_es','categoria'),('diagnostico_humano_74','referencia_humana_74.csv','pregunta','categoria_referencia')]:
  test=pd.read_csv(I/file,keep_default_na=False);shutil.copy2(I/file,O/'particiones'/file)
  paired=test.copy()
  for version,model in [('V2',baseline),('V3',selected)]:
   pred=model.predict(test[textcol]);paired[f'prediccion_{version}']=pred;paired[f'acierto_{version}']=pred==test[catcol]
   r={'conjunto':label,'modelo':version,'n':len(test),'aciertos':int((pred==test[catcol]).sum()),'exactitud':accuracy_score(test[catcol],pred),'f1_macro':f1_score(test[catcol],pred,average='macro')};summary.append(r)
   pd.DataFrame(classification_report(test[catcol],pred,labels=cats,output_dict=True,zero_division=0)).T.to_csv(O/f'metricas/reporte_{label}_{version}.csv',encoding='utf-8-sig')
   pd.DataFrame(confusion_matrix(test[catcol],pred,labels=cats),index=cats,columns=cats).to_csv(O/f'metricas/matriz_{label}_{version}.csv',encoding='utf-8-sig')
   event('evaluacion',**r)
  paired['puntaje_maximo_V3_no_calibrado']=selected.predict_proba(test[textcol]).max(axis=1)
  paired.to_csv(O/f'evidencias/predicciones_{label}.csv',index=False,encoding='utf-8-sig')
  paired.loc[~paired.acierto_V3].to_csv(O/f'evidencias/errores_{label}_V3.csv',index=False,encoding='utf-8-sig')
 pd.DataFrame(summary).to_csv(O/'metricas/resumen_comparacion.csv',index=False,encoding='utf-8-sig');dump(O/'metricas/resumen.json',summary)
 metadata={'run_id':run,'version_modelo':'3','seleccionado':name,'archivo':'modelos/modelo_seleccionado.joblib','sha256':sha(modelpath),'categorias':list(selected.classes_),'versiones':versions,'python':platform.python_version(),'entrenado_con':len(df),'features':'TF-IDF palabras 1-2 y caracteres char_wb 3-5','cv_f1_macro':float(scores.loc[scores.candidato.eq(name),'f1_macro_cv_media'].iloc[0]),'insumos_sha256':manifest,'alcance':'Clasificador académico de consultas de seguro de vida, siete categorías. No genera respuestas contractuales.','validado_para_produccion':False,'puntajes_calibrados':False,'prueba_sintetica':'Mismo autor, familias separadas, independencia semántica no garantizada.','referencia_humana':'Conjunto diagnóstico conocido durante desarrollo; no es prueba ciega.'}
 dump(O/'modelos/metadata_modelo.json',metadata);dump(O/'modelos/etiquetas.json',list(selected.classes_))
 req='\n'.join(f'{package}=={version}' for package,version in [('numpy',np.__version__),('pandas',pd.__version__),('scipy',scipy.__version__),('scikit-learn',sklearn.__version__),('joblib',joblib.__version__)])+'\n';(O/'configuracion/requirements_modelo.txt').write_text(req)
 helper='''from pathlib import Path
import json,hashlib,time,uuid
import joblib,sklearn

def cargar(ruta):
    raiz=Path(ruta);meta=json.loads((raiz/"modelos/metadata_modelo.json").read_text())
    archivo=raiz/meta["archivo"]
    if hashlib.sha256(archivo.read_bytes()).hexdigest()!=meta["sha256"]:raise ValueError("La huella del modelo no coincide")
    if sklearn.__version__!=meta["versiones"]["sklearn"]:raise RuntimeError("Usa la versión de scikit-learn registrada")
    return joblib.load(archivo),meta

def clasificar(texto,modelo,meta):
    if not isinstance(texto,str) or not texto.strip():raise ValueError("Escribe una consulta no vacía")
    inicio=time.perf_counter();texto=texto.strip();x=modelo.named_steps["tfidf"].transform([texto])
    if x.nnz==0:
        categoria=None;puntaje=None;estado="sin_caracteristicas_conocidas"
    else:
        p=modelo.named_steps["clasificador"].predict_proba(x)[0];i=int(p.argmax())
        categoria=str(modelo.classes_[i]);puntaje=float(p[i]);estado="clasificado"
    return {"request_id":uuid.uuid4().hex,"modelo_version":meta["version_modelo"],"run_id":meta["run_id"],"categoria":categoria,"puntaje_no_calibrado":puntaje,"estado":estado,"latencia_ms":(time.perf_counter()-inicio)*1000}
'''
 (O/'cargar_modelo.py').write_text(helper)
 check='''import sys,json
from pathlib import Path
import pandas as pd
from cargar_modelo import cargar,clasificar
r=Path(sys.argv[1]);m,meta=cargar(r)
queries=json.loads((r/"configuracion/consultas_recarga.json").read_text())
pred=m.predict(queries).tolist()
assert clasificar("zzzzzzzzzzzz",m,meta)["categoria"] is None
try:clasificar(" ",m,meta)
except ValueError:pass
else:raise AssertionError("Debe rechazar texto vacío")
print(json.dumps({"predicciones":pred,"carga_correcta":True,"entrada_vacia_rechazada":True,"sin_vocabulario_detectado":True}))
'''
 (O/'verificar_recarga.py').write_text(check)
 queries=pd.read_csv(I/'referencia_humana_74.csv').pregunta.tolist();dump(O/'configuracion/consultas_recarga.json',queries)
 proc=subprocess.run([sys.executable,str(O/'verificar_recarga.py'),str(O)],capture_output=True,text=True,check=True)
 rec=json.loads(proc.stdout);assert rec['predicciones']==selected.predict(queries).tolist();dump(O/'evidencias/verificacion_recarga.json',rec)
 # Medición local, sin fijar SLOs ni políticas operativas de la actividad 8.
 times=[]
 for q in queries:
  start=time.perf_counter();selected.predict_proba([q]);times.append((time.perf_counter()-start)*1000)
 dump(O/'evidencias/latencia_local.json',{'n':len(times),'mediana_ms':float(np.median(times)),'p95_ms':float(np.percentile(times,95)),'alcance':'Inferencia local por consulta, modelo ya cargado. No mide red, API ni concurrencia; no es un SLO.'})
 event('finalizado',run_id=run,seleccionado=name,sha256_modelo=sha(modelpath),recarga_verificada=True)
 (O/'USO_POSTERIOR.md').write_text(f'''# Modelo VidaSegura V3\n\nEjecución: {run}. Candidato: {name}. Entrenado con 448 preguntas de desarrollo, 64 por clase.\n\nInstala configuracion/requirements_modelo.txt en un entorno separado. Importa cargar y clasificar desde cargar_modelo.py. Ejecuta modelo, meta = cargar(ruta_de_esta_carpeta) y clasificar("tu consulta", modelo, meta). Devuelve categoría, puntaje no calibrado, identificador, versión y latencia. No devuelve una respuesta de póliza.\n\nModelo congelado: no se incorporaron las pruebas después de medir. Puntajes sin calibrar. La detección sin vocabulario no es un detector completo de fuera de alcance: textos ajenos pueden compartir palabras y recibir categoría. No hay umbral operativo validado. Solo es una base académica para instrumentación y simulaciones de la actividad 8.\n\nVer metricas/resumen_comparacion.csv: V2 y V3 se comparan sobre los mismos conjuntos. La prueba nueva es sintética del mismo autor. El Excel humano es diagnóstico conocido y revisado; no es prueba ciega. Las familias de paráfrasis se mantienen juntas en CV, pero hay cercanía temática entre familias.\n\nNo se configura todavía API, alertas, SLO, presupuesto de errores ni runbooks. Esos pasos corresponden a la actividad 8 que se hará con el usuario paso a paso.\n''',encoding='utf-8')
 checks={str(p.relative_to(O)):sha(p) for p in O.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256.json'};dump(O/'MANIFEST_SHA256.json',checks)

if __name__=='__main__':main()
