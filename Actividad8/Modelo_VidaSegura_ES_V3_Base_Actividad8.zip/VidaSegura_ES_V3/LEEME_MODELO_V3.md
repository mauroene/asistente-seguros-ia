# Modelo VidaSegura ES V3

El modelo ya está entrenado y guardado en entrenamiento/modelos/modelo_seleccionado.joblib. No necesitas volver a entrenarlo para usarlo como base de la actividad 8. Se guarda también el Colab para reproducir el proceso y crear otra ejecución en tu Drive.

## Datos y preparación

448 preguntas de desarrollo: 224 de V2 y 224 nuevas, 64 por categoría. 98 grupos de escenarios. Las 56 reservadas de V2 no se incorporaron. Se conservaron fuera del entrenamiento las 74 preguntas humanas del Excel revisado y se fijaron antes de entrenar 63 preguntas sintéticas nuevas, agrupadas en 21 familias de redacción.

Se revisaron etiquetas por intención y la escritura de las nuevas preguntas, Unicode, espacios, IDs, campos, duplicados por acentos/puntuación/mayúsculas y separación de grupos. No hay duplicados exactos normalizados entre desarrollo, prueba nueva y Excel humano. Las negaciones se conservan. No se usó traducción automática, sobremuestreo ni submuestreo. La distribución balanceada es por diseño y no representa el tráfico real.

Las referencias al PDF heredadas y temáticas acompañan los registros. No se generan respuestas, no se afirma que todas las coberturas estén contratadas ni se certifica vigencia comercial del documento. Las nuevas preguntas son sintéticas, no consultas reales de clientes.

## Modelo y selección

TF-IDF de palabras (1–2) y caracteres (3–5), con regresión logística o Random Forest. Comparación mediante cuatro particiones por grupos, sin ajustar TF-IDF con la validación. Se eligió regresión logística C=4, con F1 macro medio de 0.8162 (desviación 0.0615). Random Forest obtuvo 0.7319. La decisión se guardó antes de las pruebas y el modelo final se ajustó únicamente con las 448 preguntas de desarrollo. No hubo reajustes después de mirar resultados.

## Comparación sobre los mismos conjuntos

| Conjunto | V2 aciertos | V3 aciertos | F1 macro V2 | F1 macro V3 |
|---|---:|---:|---:|---:|
| Excel revisado, diagnóstico conocido | 48/74 (64.9%) | 65/74 (87.8%) | 0.6288 | 0.8762 |
| Prueba sintética nueva | 50/63 (79.4%) | 61/63 (96.8%) | 0.7947 | 0.9671 |

La mejora en el Excel es diagnóstica: sus errores orientaron la ampliación. La prueba nueva proviene del mismo autor y dominio; no es evaluación externa. Las familias se separaron, pero la cercanía semántica entre conjuntos puede favorecer el resultado. Ambos conjuntos son pequeños y no justifican afirmar 96.8% de precisión en producción. Se requiere otra muestra humana nueva para confirmar generalización.

Se conservaron nueve errores en el Excel y dos en la prueba nueva. Se incluyen todas las predicciones, errores, matrices, métricas por categoría, particiones, huellas y eventos. La recarga en otro proceso dio las mismas predicciones en las 74 preguntas. También se verificaron entrada vacía y texto sin vocabulario. La medición de latencia es local, con el modelo cargado; no mide una API ni establece un SLO.

## Usarlo después

Conserva el paquete ZIP completo y súbelo a una carpeta de tu Drive, por ejemplo asistente-seguros-ia/Preparacion_Modelo_Espanol/V3_Base_Actividad8. Si ejecutas el Colab, creará otra carpeta es_v3_... dentro de Preparacion_Modelo_Espanol/entrenamientos.

El archivo cargar_modelo.py comprueba versión y huella y permite clasificar texto, obteniendo categoría, puntaje sin calibrar, versión, identificador y latencia. Las dependencias están en entrenamiento/configuracion/requirements_modelo.txt. El modelo es académico, no está validado para producción. No responde preguntas contractuales ni decide coberturas o indemnizaciones. El control de vocabulario no detecta todos los textos fuera de alcance y no se ha establecido un umbral de confianza.

La actividad 8 todavía no se ha implementado: la haremos paso a paso con este modelo congelado. Primero localizaremos el entorno de la aplicación y acordaremos dónde ejecutar la integración; después instrumentaremos métricas, registros y trazas, definiremos objetivos y alertas y realizaremos las simulaciones y la documentación requeridas por la rúbrica.

## Archivos

- entrenamiento/: modelo congelado, cargador, dependencias y evidencias de la ejecución real.
- insumos/: desarrollo, prueba nueva, referencia humana, protocolo y manifiesto de entrada. baseline_v2.joblib es únicamente el modelo anterior para la comparación.
- entrenar_v3.py: procedimiento reproducible.
- preguntas_redactadas_v3.py: preguntas nuevas agrupadas y etiquetadas.
- Entrenamiento_VidaSegura_ES_V3.ipynb: Colab sin ejecutar para reproducción opcional. Las evidencias de la ejecución local ya realizada están en entrenamiento/.

La ejecución local corresponde a es_v3_20261111T023400Z_13c684 y al SHA256 073f19153c965c29db2c5061c1f9b7980a0a36b58d6cdbc6576b80b9c644456c.
