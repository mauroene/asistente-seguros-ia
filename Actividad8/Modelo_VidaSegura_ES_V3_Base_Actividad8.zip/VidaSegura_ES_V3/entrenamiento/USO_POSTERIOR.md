# Modelo VidaSegura V3

Ejecución: es_v3_20261111T023400Z_13c684. Candidato: regresion_logistica_C4. Entrenado con 448 preguntas de desarrollo, 64 por clase.

Instala configuracion/requirements_modelo.txt en un entorno separado. Importa cargar y clasificar desde cargar_modelo.py. Ejecuta modelo, meta = cargar(ruta_de_esta_carpeta) y clasificar("tu consulta", modelo, meta). Devuelve categoría, puntaje no calibrado, identificador, versión y latencia. No devuelve una respuesta de póliza.

Modelo congelado: no se incorporaron las pruebas después de medir. Puntajes sin calibrar. La detección sin vocabulario no es un detector completo de fuera de alcance: textos ajenos pueden compartir palabras y recibir categoría. No hay umbral operativo validado. Solo es una base académica para instrumentación y simulaciones de la actividad 8.

Ver metricas/resumen_comparacion.csv: V2 y V3 se comparan sobre los mismos conjuntos. La prueba nueva es sintética del mismo autor. El Excel humano es diagnóstico conocido y revisado; no es prueba ciega. Las familias de paráfrasis se mantienen juntas en CV, pero hay cercanía temática entre familias.

No se configura todavía API, alertas, SLO, presupuesto de errores ni runbooks. Esos pasos corresponden a la actividad 8 que se hará con el usuario paso a paso.
