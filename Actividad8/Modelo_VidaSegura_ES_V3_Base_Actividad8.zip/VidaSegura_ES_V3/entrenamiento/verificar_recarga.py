import sys,json
from pathlib import Path
import pandas as pd
from cargar_modelo import cargar,clasificar
r=Path(sys.argv[1]);m,meta=cargar(r)
queries=json.loads((r/"configuracion/consultas_recarga.json").read_text())
pred=m.predict(queries).tolist()
assert clasificar("zzzzzzzzzzzz",m,meta)["categoria"] is None
try:clasificar(" ",m,meta)
except ValueError:pass
else:raise AssertionError("Debe rechazar texto vacío")
print(json.dumps({"predicciones":pred,"carga_correcta":True,"entrada_vacia_rechazada":True,"sin_vocabulario_detectado":True}))
