from pathlib import Path
import json,hashlib,time,uuid
import joblib,sklearn

def cargar(ruta):
    raiz=Path(ruta);meta=json.loads((raiz/"modelos/metadata_modelo.json").read_text())
    archivo=raiz/meta["archivo"]
    if hashlib.sha256(archivo.read_bytes()).hexdigest()!=meta["sha256"]:raise ValueError("La huella del modelo no coincide")
    if sklearn.__version__!=meta["versiones"]["sklearn"]:raise RuntimeError("Usa la versión de scikit-learn registrada")
    return joblib.load(archivo),meta

def clasificar(texto,modelo,meta):
    if not isinstance(texto,str) or not texto.strip():raise ValueError("Escribe una consulta no vacía")
    inicio=time.perf_counter();texto=texto.strip();x=modelo.named_steps["tfidf"].transform([texto])
    if x.nnz==0:
        categoria=None;puntaje=None;estado="sin_caracteristicas_conocidas"
    else:
        p=modelo.named_steps["clasificador"].predict_proba(x)[0];i=int(p.argmax())
        categoria=str(modelo.classes_[i]);puntaje=float(p[i]);estado="clasificado"
    return {"request_id":uuid.uuid4().hex,"modelo_version":meta["version_modelo"],"run_id":meta["run_id"],"categoria":categoria,"puntaje_no_calibrado":puntaje,"estado":estado,"latencia_ms":(time.perf_counter()-inicio)*1000}
