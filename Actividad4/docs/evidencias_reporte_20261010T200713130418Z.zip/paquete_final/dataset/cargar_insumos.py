# Cargar los insumos finales sin repetir la preparación del dataset
import pandas as pd
import json
import hashlib
from pathlib import Path

# Ajustar esta ruta a la carpeta donde se descomprimió el ZIP
carpeta_insumos = Path("/content/dataset_final")

# Verificar que los archivos coincidan con el respaldo exportado
with (carpeta_insumos / "manifest.json").open(
    encoding="utf-8"
) as archivo:
    manifest = json.load(archivo)

for nombre, datos in manifest["archivos"].items():
    ruta = carpeta_insumos / nombre
    if not ruta.is_file():
        raise FileNotFoundError(f"Falta el insumo: {ruta}")
    huella = hashlib.sha256(ruta.read_bytes()).hexdigest()
    if huella != datos["sha256"]:
        raise ValueError(f"El archivo cambió: {nombre}")

df_dataset_desarrollo = pd.read_csv(
    carpeta_insumos / "dataset_desarrollo.csv",
    encoding="utf-8-sig",
    keep_default_na=False
)
df_dataset_prueba = pd.read_csv(
    carpeta_insumos / "dataset_prueba.csv",
    encoding="utf-8-sig",
    keep_default_na=False
)

with (carpeta_insumos / "configuracion_para_prueba.json").open(
    encoding="utf-8"
) as archivo:
    registro_configuracion = json.load(archivo)

modelos_comparacion = registro_configuracion["modelos"]
configuracion_prueba = registro_configuracion["configuracion_prueba"]
decision_desarrollo = registro_configuracion["decision_desarrollo"]

consultas_prueba = df_dataset_prueba["consulta_es"].tolist()
etiquetas_prueba = df_dataset_prueba["categoria_referencia"].tolist()

print("=" * 60)
print("✅ Insumos verificados y cargados.")
print("Desarrollo:", len(df_dataset_desarrollo))
print("Prueba:", len(df_dataset_prueba))
print("Configuración para prueba recuperada.")
print("No es necesario repetir el muestreo ni las traducciones.")
print("La inferencia requiere cargar las bibliotecas y los modelos.")
print("=" * 60)
