# Clasificar nuevas consultas con el modelo seleccionado
# Requiere: torch y transformers instalados.
import json
import torch
from pathlib import Path
from transformers import pipeline

# Ajustar a la carpeta donde se descomprimió el paquete final
carpeta_paquete = Path("/content/paquete_final")

with (carpeta_paquete / "configuracion_modelo_final.json").open(
    encoding="utf-8"
) as archivo:
    registro_modelo = json.load(archivo)

configuracion = registro_modelo["configuracion"]
categorias = registro_modelo["categorias"]
descripciones = configuracion["descripciones"]

descripcion_a_categoria = {
    descripciones[categoria]: categoria
    for categoria in categorias
}

clasificador_final = pipeline(
    "zero-shot-classification",
    model=registro_modelo["identificador_hugging_face"],
    device=0 if torch.cuda.is_available() else -1,
    dtype=torch.float32
)

def clasificar_consultas(consultas):
    """Clasifica una consulta o una lista de consultas en español."""
    if isinstance(consultas, str):
        consultas = [consultas]

    if not isinstance(consultas, list) or not consultas:
        raise ValueError("Introduce una consulta o una lista no vacía.")

    if any(
        not isinstance(texto, str) or not texto.strip()
        for texto in consultas
    ):
        raise ValueError("Todas las consultas deben ser textos no vacíos.")

    with torch.inference_mode():
        salidas = clasificador_final(
            consultas,
            candidate_labels=[
                descripciones[categoria] for categoria in categorias
            ],
            hypothesis_template=configuracion["plantilla"],
            multi_label=configuracion["multi_label"],
            batch_size=configuracion["batch_size"]
        )

    return [
        {
            "consulta": texto,
            "categoria_predicha": descripcion_a_categoria[
                salida["labels"][0]
            ],
            "puntuacion": float(salida["scores"][0])
        }
        for texto, salida in zip(consultas, salidas)
    ]

print("✅ Modelo seleccionado cargado:", registro_modelo["nombre_modelo"])
print("Usa clasificar_consultas('Tu consulta en español').")
print("La puntuación no es una probabilidad calibrada de acierto.")
