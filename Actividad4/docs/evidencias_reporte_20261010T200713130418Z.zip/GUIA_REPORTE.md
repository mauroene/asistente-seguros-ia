# Guía de evidencias para redactar el reporte

## Estado de los requisitos

Las instrucciones y la rúbrica exactas todavía deben incorporarse.
Esta guía reúne evidencias; no certifica cumplimiento de la rúbrica.

## Datos y preparación

Se prepararon 300 consultas de seis categorías:
60 de desarrollo y 240 de prueba.
Cada categoría tiene 10 consultas de desarrollo y 40 de prueba.

Las traducciones fueron revisadas y aprobadas por el usuario.
Se conservaron los originales y la auditoría de 48 registros retirados.
Se eliminaron las coincidencias textuales detectadas con la normalización
utilizada. Pueden persistir consultas semánticamente similares.

Consultar los archivos de la subcarpeta paquete_final/dataset.

## Protocolo

Se evaluaron tres modelos con una configuración común fijada en desarrollo.
La plantilla fue: Esta consulta trata sobre {}.
El tamaño de lote fue 1 y se realizaron tres repeticiones.
La evaluación de prueba se ejecutó en Tesla T4.
El criterio principal fue F1 macro.

Las métricas corresponden a la primera repetición.
Las etiquetas fueron estables entre repeticiones.
Estas repeticiones no representan muestras independientes.

## Experimento de desarrollo

Se compararon descripciones iniciales y alternativas sobre desarrollo.
La configuración inicial se conservó para la comparación común en prueba.
Consultar experimentos_desarrollo/efecto_descripciones.csv y sus registros.
No atribuir los cambios entre reconstrucciones del dataset exclusivamente
a la eliminación de expresiones ofensivas.

## Resultados sobre prueba

- XLM-RoBERTa-large: exactitud 0.6583; F1 macro 0.6492; tiempo medio total 26.6031 segundos.
- MiniLMv2 multilingüe: exactitud 0.4417; F1 macro 0.4002; tiempo medio total 18.5258 segundos.
- mDeBERTa-v3-base: exactitud 0.3125; F1 macro 0.2893; tiempo medio total 34.0984 segundos.

Consultar comparacion_prueba.csv para los valores completos.

## Selección final

Modelo: XLM-RoBERTa-large
Identificador: joeddav/xlm-roberta-large-xnli
F1 macro: 0.6492
Aciertos: 158 de 240
Errores: 82

Se seleccionó por obtener el mayor F1 macro entre los modelos comparados.

## Análisis por categoría y errores

Usar las métricas por categoría, matrices de confusión y archivos de errores.
La correspondencia entre modelo_N y el nombre del modelo se encuentra en
resultados_prueba/registro_evaluacion.json.

Elegir ejemplos directamente de los archivos de errores.
No inventar consultas ni causas de las confusiones.

## Limitaciones

- Muestra traducida, revisada y limitada a seis categorías.
- Posible similitud semántica entre consultas de ambos conjuntos.
- Los tiempos dependen de esta ejecución y del entorno.
- MiniLMv2 mostró variación considerable de tiempos entre repeticiones.
- El tiempo por consulta es un promedio del procesamiento completo.
- Las puntuaciones no son probabilidades calibradas.
- La selección no demuestra suficiencia para uso operativo.

## Continuación sin repetir el trabajo

Para recuperar datos:
paquete_final/dataset/cargar_insumos.py

Para clasificar nuevas consultas:
paquete_final/usar_modelo_seleccionado.py

Ajustar las rutas dentro de esos archivos a la ubicación del paquete
descomprimido. La carga del modelo requiere sus bibliotecas y pesos.

## Pendiente para terminar el reporte

1. Incorporar las instrucciones y la rúbrica exactas.
2. Relacionar cada requisito con una evidencia del inventario.
3. Preparar las tablas y figuras exigidas.
4. Redactar el reporte en el formato y extensión solicitados.
5. Verificar las fuentes y referencias requeridas.
6. Revisar el cumplimiento antes de entregar.
